﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp4.Properties;





namespace WindowsFormsApp4
{
    public partial class Form1 : Form
         
    {
        string connection = @"Server=LAPTOP-3BDRILU2\SQLEXPRESS;Database=obuv_2;Trusted_Connection=True;";

       
        public Form1()
        {
           
            InitializeComponent();
            

        }




        private void button2_Click(object sender, EventArgs e)
        {
            
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
     
        }



        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {


                MessageBox.Show("Для авторизации должны быть заполнены все поля");

            }
            using (SqlConnection sql = new SqlConnection(connection))

            {
                sql.Open();

                string query = "select Users.login, Users.name , Role.name_role from Users join Role on Role.id_role = Users.role_id where Users.login = @login and Users.password = @password";
                SqlCommand sqlCommand = new SqlCommand(query, sql);

                sqlCommand.Parameters.Clear();

                sqlCommand.Parameters.AddWithValue("login", textBox1.Text);
                sqlCommand.Parameters.AddWithValue("password", textBox2.Text);

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                if (sqlDataReader.Read())
                {
                    string log = sqlDataReader["login"].ToString();
                    string name_r = sqlDataReader["name_role"].ToString();
                  string name_user = sqlDataReader["name"].ToString();

                    Form2 form2 = new Form2(log, name_r, name_user);
                    form2.Show();
                    this.Hide();
                }

                else
                    {
                        MessageBox.Show("Такого пользователя не найдено, введите существующие данные", "Ошибка", MessageBoxButtons.OK , MessageBoxIcon.Error);
                    }
                sql.Close();

            }



                

            }
        }
           

  }


        
                


        
    

