﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;



namespace WindowsFormsApp4
{
    public partial class Form2 : Form
    {
        string connection = @"Server=LAPTOP-3BDRILU2\SQLEXPRESS;Database=obuv_2;Trusted_Connection=True;";
        private string role_user;
        public Form2(string login, string role , string name)
        {

            InitializeComponent();
            role_user = role;
            label1.Text = name;
            if (role == "Менеджер")
            {
                button2.Visible = true;
                radioButton1.Visible = true;
                radioButton2.Visible = true;
                button2.Visible = false;
                button3.Visible = false;

            }
            if (role == "Администратор")
            {
                button2.Visible = true;
                radioButton1.Visible = true;
                radioButton2.Visible = true;

            }
            if (role == "Клиент")
            {
                button2.Visible = false;
                radioButton1.Visible = false;
                radioButton2.Visible = false;
                textBox1.Visible = false;
                comboBox1.Visible = false;
                button2.Visible = false;
                button3.Visible=false;
                button4.Visible = false;
               
            }
            
            Spipisok();
            Load();
            
            //Spipisok();
            

        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void Load()
        {
            using (SqlConnection sql = new SqlConnection(connection))

            {
                sql.Open();
                string loadProduckt = " select Product.id_product, Product.name_product, Product.image_path, Categories.name_category, Product.description," +
                    " Providers.name_provider, Creators.name_creator, Product.price, Units.name_unit, Product.quantity, Product.discount" +
                    " from Product" +
" join Providers on Providers.id_provider = Product.provider_id " +
" join Categories on Categories.id_category = Product.category_id" +
" join Creators on Creators.id_creator = Product.creator_id" +
" join Units on Units.id_unit = Product.unit_id ";

                SqlDataAdapter dataAdapter = new SqlDataAdapter(loadProduckt, sql);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;


                dataGridView1.Columns["id_product"].Visible = false;
                dataGridView1.Columns["image_path"].Visible = false;
                //dataGridView1.Columns["provider_id"].Visible = false;
                //dataGridView1.Columns["category_id"].Visible = false;
                //dataGridView1.Columns["creator_id"].Visible = false;
                //dataGridView1.Columns["unit_id"].Visible = false;

            }

        }


      
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;

            string path = dataGridView1.CurrentRow.Cells["image_path"].Value?.ToString();

            if (!string.IsNullOrEmpty(path) && File.Exists(path))
            {
                pictureBox1.Image = Image.FromFile(path);
            }
            //else
            //{
            //    pictureBox1.Image = Properties.Resources.rMqbsLCdsr3HONLK_di9szOMddsyzW7p2xLqnQrvnegZ4vrgqX0pv18NbUw0WCfZv5yWX_XVUY5hZOx9H6vHS7I5;
            //}
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 formi4 = new Form4();
            formi4.ShowDialog();
            Load();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            if (role_user == "Администратор")
            {
                int id2 = int.Parse(dataGridView1.CurrentRow.Cells["id_product"].Value.ToString());
                Form5 form5 = new Form5(id2);
                form5.ShowDialog();
                Load();
            }
            else 
            {
                return;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult ds = MessageBox.Show("Ты уверен?", "УДаление", MessageBoxButtons.YesNo);
            if (ds == DialogResult.Yes)
            {
                using (SqlConnection sql = new SqlConnection(connection))

                {

                    sql.Open();
                    int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["id_product"].Value); 
                    string delete = "delete from product where id_product = @id ";
                    SqlCommand sqlCommand = new SqlCommand(delete, sql);
                    sqlCommand.Parameters.AddWithValue("@id", id);
                    sqlCommand.ExecuteNonQuery();
                }
                Load();
            }
            else { return; }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            dataGridView1.Sort(dataGridView1.Columns["quantity"], System.ComponentModel.ListSortDirection.Descending);
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            dataGridView1.Sort(dataGridView1.Columns["quantity"], System.ComponentModel.ListSortDirection.Ascending);
        }

        public class filtre
        {
            public string nf { get; set; }
            public int pi { get; set; }
        }


        private void Spipisok()
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                string zapros = "select* from Providers";
                SqlCommand cnd = new SqlCommand(zapros, con);
                SqlDataReader rdr = cnd.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(rdr);
                DataRow n = dt.NewRow();
                n["name_provider"] = "Просмотр";
                dt.Rows.InsertAt(n, 0);
                comboBox1.DataSource = dt;
                comboBox1.DisplayMember = "name_provider";
                comboBox1.ValueMember = "name_provider";

            }
        }

        private void Kategoriya(object sender, EventArgs e)
        {
            if (comboBox1.Text.ToString() == "Просмотр")
            {
                Load();
                return;
            }
            else
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();
                    string zapros = "select Product.id_product, Product.image_path ,Product.name_product, Product.price, Product.quantity, Product.discount, Product.description," +
                        " Providers.name_provider, Categories.name_category, Creators.name_creator, Units.name_unit" +
                        " from Product join Providers on Product.provider_id = Providers.id_provider" +
                        " join Categories on Product.category_id = Categories.id_category" +
                        " join Creators on Product.creator_id = Creators.id_creator" +
                        " join Units on Product.unit_id = Units.id_unit" +
                        " where Providers.name_provider = @name_provider";
                    SqlCommand cmd = new SqlCommand(zapros, con);
                    cmd.Parameters.AddWithValue("@name_provider", comboBox1.SelectedValue.ToString());
                    SqlDataReader rdr = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(rdr);
                    dataGridView1.DataSource = dt;

                }
            }

        }

        private void Poisk(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text.ToString()))
            {
                Load();
                return;
            }
            else
            {
                using (SqlConnection sql = new SqlConnection(connection))
                {
                    sql.Open();
                    string poi = "select Product.id_product, Product.name_product, Product.image_path, Product.price, Product.quantity, Product.discount, Product.description," +
                        " Providers.name_provider, Categories.name_category, Creators.name_creator, Units.name_unit" +
                        " from Product join Providers on Product.provider_id = Providers.id_provider" +
                        " join Categories on Product.category_id = Categories.id_category" +
                        " join Creators on Product.creator_id = Creators.id_creator" +
                        " join Units on Product.unit_id = Units.id_unit" +
                        " where Product.name_product like @poisk or Product.description like @poisk or Providers.name_provider like @poisk;";
                    SqlCommand sqlCommand = new SqlCommand(poi, sql);
                    sqlCommand.Parameters.AddWithValue("@poisk", "%" + textBox1.Text.Trim() + "%");
                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(sqlDataReader);
                    dataGridView1.DataSource = dt;
                    dataGridView1.Columns["image_path"].Visible = false;

                }
            }
        }

    }

}


