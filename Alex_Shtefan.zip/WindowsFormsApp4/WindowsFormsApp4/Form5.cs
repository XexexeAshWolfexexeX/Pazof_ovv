﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp4
{
    
    public partial class Form5 : Form
    {
        string connection = @"Server=LAPTOP-3BDRILU2\SQLEXPRESS;Database=obuv_2;Trusted_Connection=True;";
        //private int productid = 0;
        int proId;
        public Form5(int i)
        {

            InitializeComponent();
            //productid = idb;
            
            textBox4.Visible = false;
            proId = i;
            vsravca();
            //MessageBox.Show(proId.ToString());
        }
       
        public class Provider
        {
            public int id { get; set; }
            public string name { get; set; }

        }

       
        private void spisocall(string p, System.Windows.Forms.ComboBox combo )
        {

            using (SqlConnection sql = new SqlConnection(connection))

            {

                sql.Open();

                string prodiders = p;
                

                SqlCommand sqlCommand = new SqlCommand(prodiders, sql);
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();


                List<Provider> list = new List<Provider>();


                while (sqlDataReader.Read())
                {
                    list.Add(new Provider { id = sqlDataReader.GetInt32(0), name = sqlDataReader.GetString(1) });

                }

                combo.DataSource = list;
                combo.DisplayMember = "name";
                combo.ValueMember = "id";




                sql.Close();





            }


        }
        private void vsravca()
        {
            spisocall("select  * from Providers", comboBox1);
            spisocall("select  * from Creators", comboBox2);
            spisocall("select  * from Categories", comboBox3);
            using (SqlConnection sql = new SqlConnection(connection))
            {
                sql.Open();
             
                string vse = " select Categories.id_category, Creators.id_creator, Providers.id_provider ,Product.id_product , Product.name_product, Product.image_path, Categories.name_category, Product.description," +
                       " Providers.name_provider, Creators.name_creator, Product.price, Units.name_unit, Product.quantity, Product.discount" +
                       " from Product" +
    " join Providers on Providers.id_provider = Product.provider_id " +
    " join Categories on Categories.id_category = Product.category_id" +
    " join Creators on Creators.id_creator = Product.creator_id" +
    " join Units on Units.id_unit = Product.unit_id  where Product.id_product = @proId";

                SqlCommand sqlcommand = new SqlCommand(vse, sql);
                sqlcommand.Parameters.AddWithValue("@proId", proId);
                sqlcommand.ExecuteNonQuery();

                SqlDataReader sqlDataReader = sqlcommand.ExecuteReader();
                if (sqlDataReader.Read())
                {
               
                    textBox1.Text = sqlDataReader["name_product"].ToString();
                    textBox2.Text = sqlDataReader["description"].ToString();
                    textBox3.Text = sqlDataReader["price"].ToString();
                    //textBox4.Text = sqlDataReader["unit_id"].ToString();
                    textBox5.Text = sqlDataReader["quantity"].ToString();
                    textBox6.Text = sqlDataReader["discount"].ToString();
                    textBox7.Text = sqlDataReader["image_path"].ToString();
                    comboBox1.SelectedValue = sqlDataReader["id_provider"];
                    comboBox2.SelectedValue = sqlDataReader["id_creator"];
                    comboBox3.SelectedValue = sqlDataReader["id_category"];


                    //comboBox1.DisplayMember = sqlDataReader["name_provider"].ToString();
                    //comboBox2.DisplayMember = sqlDataReader["name_creator"].ToString();
                    //comboBox3.DisplayMember = sqlDataReader["name_category"].ToString();
                }
                //string pos = sqlDataReader["name_provider"].ToString();

                //MessageBox.Show(pos);
                    sql.Close();

             
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox3.Text) || string.IsNullOrWhiteSpace(textBox5.Text) || string.IsNullOrWhiteSpace(textBox6.Text)) // можно ли проще тут
            {

                MessageBox.Show(" одно или несколько полей не прошли проверку", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!decimal.TryParse(textBox3.Text, out decimal price))
            {

                MessageBox.Show("цена должна быть числом", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            
            }

            if (!int.TryParse(textBox5.Text, out int count)) 
            {

                MessageBox.Show(" количество должно быть целочисленым значением", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;

            }

            if (!int.TryParse(textBox6.Text, out int discount))
            {
                MessageBox.Show("Скидка должна быть целочисеным значением", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if(price  < 0 || count < 0 || discount < 0)

            {
                MessageBox.Show("Значение чисел не может быть отрицательным", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
                
            }
            if (discount > 50)
            {
                MessageBox.Show("скидка не должна превышать порог более 50 процентов", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning );
                return;

            }

            string query1 = "select id_provider from Providers WHERE name_provider = @provivi";
            using (SqlConnection sql = new SqlConnection(connection))
                
            { 
                sql.Open();



                SqlCommand sqlCommand1 = new SqlCommand(query1, sql);


            }








            using (SqlConnection sql = new SqlConnection(connection))

            {

                sql.Open();
                string prodiders = " update Product set name_product =  @name_product, description =  @description, price = @price, unit_id = @unit_id, " +
                    " quantity =  @quantity, discount =  @discount, provider_id =  @provider_id, creator_id = @creator_id, category_id = @category_id, image_path = @image_path where id_product = @id_product ";
                    



                SqlCommand sqlCommand = new SqlCommand(prodiders, sql);
                

                

                sqlCommand.Parameters.AddWithValue("id_product", proId);


                sqlCommand.Parameters.AddWithValue("name_product", textBox1.Text);
                sqlCommand.Parameters.AddWithValue("description", textBox2.Text);
                sqlCommand.Parameters.AddWithValue("price", decimal.Parse(textBox3.Text));


                sqlCommand.Parameters.AddWithValue("unit_id", 1);


                sqlCommand.Parameters.AddWithValue("quantity", int.Parse(textBox5.Text));
                sqlCommand.Parameters.AddWithValue("discount", int.Parse(textBox6.Text));
                sqlCommand.Parameters.AddWithValue("provider_id", int.Parse(comboBox1.SelectedValue.ToString()));
                sqlCommand.Parameters.AddWithValue("creator_id", int.Parse(comboBox2.SelectedValue.ToString()));
                sqlCommand.Parameters.AddWithValue("category_id", int.Parse(comboBox3.SelectedValue.ToString()));
                sqlCommand.Parameters.AddWithValue("image_path", textBox7.Text);

               
                sqlCommand.ExecuteNonQuery(); 

                sql.Close();
                
            }
            
            this.Close();
            }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    }

