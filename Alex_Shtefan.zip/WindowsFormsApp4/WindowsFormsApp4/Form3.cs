﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp4
{
    public partial class Form3 : Form
    {
        string connection = @"Server=LAPTOP-3BDRILU2\SQLEXPRESS;Database=obuv_2;Trusted_Connection=True;";
        public Form3()
        {
            InitializeComponent();
            Load();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        

        private void Load()
        {
            using (SqlConnection sql = new SqlConnection(connection))

            {
                sql.Open();
                string loadProduckt = " select Product.id_product, Product.name_product, Product.image_path, Categories.name_category, Product.description," +
                    " Providers.name_provider, Creators.name_creator, Product.price, Units.name_unit, Product.quantity, Product.discount" +
                    " from Product" +
" join Providers on Providers.id_provider = Product.provider_id " +
" join Categories on Categories.id_category = Product.category_id" +
" join Creators on Creators.id_creator = Product.creator_id" +
" join Units on Units.id_unit = Product.unit_id ";

                SqlDataAdapter dataAdapter = new SqlDataAdapter(loadProduckt, sql);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;


                dataGridView1.Columns["id_product"].Visible = false;
                dataGridView1.Columns["image_path"].Visible = false;
                //dataGridView1.Columns["provider_id"].Visible = false;
                //dataGridView1.Columns["category_id"].Visible = false;
                //dataGridView1.Columns["creator_id"].Visible = false;
                //dataGridView1.Columns["unit_id"].Visible = false;

            }

        }



        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;

            string path = dataGridView1.CurrentRow.Cells["image_path"].Value?.ToString();

            if (!string.IsNullOrEmpty(path) && File.Exists(path))
            {
                pictureBox1.Image = Image.FromFile(path);
            }
            ////    else
            ////    {
            ////        pictureBox1.Image = Properties.Resources.rMqbsLCdsr3HONLK_di9szOMddsyzW7p2xLqnQrvnegZ4vrgqX0pv18NbUw0WCfZv5yWX_XVUY5hZOx9H6vHS7I5;
            ////    }
        }
















    }

}
