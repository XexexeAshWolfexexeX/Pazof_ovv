﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp4
{
    
    public partial class Form4 : Form
    {
        string connection = @"Server=LAPTOP-3BDRILU2\SQLEXPRESS;Database=obuv_2;Trusted_Connection=True;";
        //private int productid = 0;
        public Form4()
        {

            InitializeComponent();
            //productid = idb;
            spisocall("select  * from Providers",comboBox1);
            spisocall("select  * from Creators", comboBox2);
            spisocall("select  * from Categories", comboBox3);
            textBox4.Visible = false;
             
        }
       
        public class Provider
        {
            public int id { get; set; }
            public string name { get; set; }

        }

       
        private void spisocall(string p, System.Windows.Forms.ComboBox combo )
        {

            using (SqlConnection sql = new SqlConnection(connection))

            {

                sql.Open();

                string prodiders = p;
                

                SqlCommand sqlCommand = new SqlCommand(prodiders, sql);
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();


                List<Provider> list = new List<Provider>();


                while (sqlDataReader.Read())
                {
                    list.Add(new Provider { id = sqlDataReader.GetInt32(0), name = sqlDataReader.GetString(1) });

                }

                combo.DataSource = list;
                combo.DisplayMember = "name";
                combo.ValueMember = "id";




                sql.Close();





            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox3.Text) || string.IsNullOrWhiteSpace(textBox5.Text) || string.IsNullOrWhiteSpace(textBox6.Text)) // можно ли проще тут
            {

                MessageBox.Show(" одно или несколько полей не прошли проверку");
                return;
            }
            if (!decimal.TryParse(textBox3.Text, out decimal price))
            {
                
                MessageBox.Show("цена должна быть числом" );
                return;
            
            }

            if (!int.TryParse(textBox5.Text, out int count)) 
            {
                

                MessageBox.Show(" количество должно быть целочисленым значением" , "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;

            }

            if (!int.TryParse(textBox6.Text, out int discount))
            {
                MessageBox.Show("Скидка должна быть целочисеным значением" , "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if(price  < 0 || count < 0 || discount < 0)

            {
                MessageBox.Show("Значение чисел не может быть отрицательным", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
                
            }
            if (discount > 50)
            {
                MessageBox.Show("скидка не должна превышать порог более 50 процентов", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;

            }

            string query1 = "select id_provider from Providers WHERE name_provider = @provivi";
            using (SqlConnection sql = new SqlConnection(connection))
                
            { 
                sql.Open();


             




                SqlCommand sqlCommand1 = new SqlCommand(query1, sql);


            }








            using (SqlConnection sql = new SqlConnection(connection))

            {

                sql.Open();
                MessageBox.Show(comboBox1.SelectedValue?.ToString());
                string prodiders = " insert into Product(name_product, description, price, unit_id," +
                    " quantity, discount, provider_id, creator_id, category_id, image_path) values " +
                    " ( @name_product,  @description, @price," +
                    " @unit_id,  @quantity,  @discount, @provider_id,  @creator_id, @category_id," +
                    "  @image_path )";



                SqlCommand sqlCommand = new SqlCommand(prodiders, sql);

                sqlCommand.Parameters.AddWithValue("name_product", textBox1.Text);
                sqlCommand.Parameters.AddWithValue("description", textBox2.Text);
                sqlCommand.Parameters.AddWithValue("price", (textBox3.Text));


                sqlCommand.Parameters.AddWithValue("unit_id", 1);


                sqlCommand.Parameters.AddWithValue("quantity", textBox5.Text);
                sqlCommand.Parameters.AddWithValue("discount", (textBox6.Text));
                sqlCommand.Parameters.AddWithValue("provider_id", comboBox1.SelectedValue);
                sqlCommand.Parameters.AddWithValue("creator_id", comboBox2.SelectedValue);
                sqlCommand.Parameters.AddWithValue("category_id", comboBox3.SelectedValue);
                sqlCommand.Parameters.AddWithValue("image_path", textBox7.Text);


                sqlCommand.ExecuteNonQuery();

                sql.Close();
                
            }
            
            this.Close();
            }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    }

